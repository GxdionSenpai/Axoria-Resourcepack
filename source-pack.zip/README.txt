AXORIA VANILLA RESOURCEPACK – MINECRAFT JAVA 26.3

Diese Version braucht KEINE OptiFine/CIT-Mod. Fabric + Sodium funktionieren ebenfalls.
Die Axoria-Plugin-JAR muss aktualisiert sein: Das Plugin vergibt item_model=axoria:<id>.
Das Resourcepack alleine verändert KEINE normalen Gegenstände anhand ihres Namens.
Alle zehn Gegenstände haben unverwechselbare IDs; Umbenennen eines normalen Gegenstands reicht NICHT.

Installation:
1. ZIP unverändert im Minecraft-Resourcepacks-Ordner ablegen und aktivieren.
2. Neue AxoSkyblock-JAR vom erfolgreichen GitHub-Actions-Build auf G-Portal installieren.
3. Server neu starten, neue Custom Items vergeben und testen.
4. Vorhandene ältere Custom Items benötigen ggf. eine einmalige Migration/Neuausgabe,
   da deren item_model-Komponente noch fehlt.

Hinweis: Für automatischen Download beim Betreten muss die ZIP öffentlich per HTTPS
bereitgestellt und als Resourcepack-URL im Server hinterlegt werden.
